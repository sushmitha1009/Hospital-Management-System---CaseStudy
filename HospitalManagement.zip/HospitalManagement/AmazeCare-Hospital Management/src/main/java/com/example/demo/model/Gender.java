package com.example.demo.model;

public enum Gender {
	
	Male,Female,Other

}
