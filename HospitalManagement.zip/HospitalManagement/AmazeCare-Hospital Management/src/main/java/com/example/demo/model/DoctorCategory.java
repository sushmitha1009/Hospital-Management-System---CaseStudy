package com.example.demo.model;

public enum DoctorCategory {
    Cardiology,
    Orthopedics,
    Pediatrics,
    Neurology,
    Dermatology,
    GeneralMedicine,
    Anesthesia,
    Psychiatry,
    ENT
}
